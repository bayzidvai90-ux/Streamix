package com.example.ui.screens.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.StreamixRepository
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassTextField
import com.example.ui.theme.CoralRed
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepIndigoBg
import com.example.ui.theme.GlassCardBorder
import com.example.ui.theme.GlassSurfaceDark
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyanGradient
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VibrantPurple
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    repository: StreamixRepository,
    onLoginSuccess: () -> Unit,
    onNavigateToSignUp: () -> Unit,
    onNavigateToForgotPassword: () -> Unit,
    onNavigateToAdmin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var usernameOrEmail by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Brand Logo
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(PurpleCyanGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = MidnightBlack,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "STREAMIX BD",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )

            Text(
                text = "Premium Bangladeshi OTT Entertainment",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Glass Container Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = GlassSurfaceDark
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Sign In",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Access your watchlist, downloads & streams",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    GlassTextField(
                        value = usernameOrEmail,
                        onValueChange = {
                            usernameOrEmail = it
                            errorMessage = null
                        },
                        label = "Username or Email",
                        placeholder = "tanvir_bd or user@email.com",
                        leadingIcon = Icons.Default.Person,
                        testTag = "login_username_input"
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    GlassTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = null
                        },
                        label = "Password",
                        placeholder = "••••••••",
                        leadingIcon = Icons.Default.Lock,
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password",
                                    tint = TextSecondary
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        isPassword = !passwordVisible,
                        testTag = "login_password_input"
                    )

                    // Error banner
                    AnimatedVisibility(visible = errorMessage != null) {
                        errorMessage?.let { msg ->
                            Text(
                                text = msg,
                                color = CoralRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }

                    // Forgot Password Link
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onNavigateToForgotPassword) {
                            Text(
                                text = "Forgot Password?",
                                color = NeonCyan,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Sign In Action
                    if (isLoading) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(28.dp))
                        }
                    } else {
                        GlassButton(
                            text = "Sign In",
                            onClick = {
                                if (usernameOrEmail.isBlank() || password.isBlank()) {
                                    errorMessage = "Please enter username/email and password"
                                    return@GlassButton
                                }
                                isLoading = true
                                scope.launch {
                                    val result = repository.login(usernameOrEmail, password)
                                    isLoading = false
                                    if (result.isSuccess) {
                                        onLoginSuccess()
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.message ?: "Login failed"
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "login_submit_btn"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Navigation to Sign Up
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Don't have an account?",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                TextButton(onClick = onNavigateToSignUp) {
                    Text(
                        text = "Sign Up",
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dedicated Separate 👑 Admin Panel Entry Option
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_admin_panel_entry_btn"),
                backgroundColor = DeepIndigoBg.copy(alpha = 0.85f),
                borderColor = VibrantPurple.copy(alpha = 0.8f),
                onClick = onNavigateToAdmin
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "👑",
                            fontSize = 20.sp
                        )
                        Column {
                            Text(
                                text = "Admin Panel",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Restricted OTT Management Portal",
                                color = VibrantPurple,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Filled.AdminPanelSettings,
                        contentDescription = "Admin Panel",
                        tint = NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "© Streamix BD Official • v10.0.1",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun SignUpScreen(
    repository: StreamixRepository,
    onSignUpSuccess: () -> Unit,
    onNavigateToLogin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "CREATE ACCOUNT",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Join Streamix BD for authorized OTT streaming",
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = GlassSurfaceDark
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    GlassTextField(
                        value = fullName,
                        onValueChange = { fullName = it; errorMessage = null },
                        label = "Full Name",
                        placeholder = "e.g. Mahfuzur Rahman",
                        leadingIcon = Icons.Default.Person,
                        testTag = "signup_name_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    GlassTextField(
                        value = username,
                        onValueChange = { username = it; errorMessage = null },
                        label = "Username",
                        placeholder = "e.g. mahfuz_bd",
                        leadingIcon = Icons.Default.Person,
                        testTag = "signup_username_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    GlassTextField(
                        value = email,
                        onValueChange = { email = it; errorMessage = null },
                        label = "Email Address",
                        placeholder = "name@example.com",
                        leadingIcon = Icons.Default.Email,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        testTag = "signup_email_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    GlassTextField(
                        value = password,
                        onValueChange = { password = it; errorMessage = null },
                        label = "Password",
                        placeholder = "Minimum 6 characters",
                        leadingIcon = Icons.Default.Lock,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        isPassword = true,
                        testTag = "signup_password_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    GlassTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it; errorMessage = null },
                        label = "Confirm Password",
                        placeholder = "Re-enter password",
                        leadingIcon = Icons.Default.Lock,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        isPassword = true,
                        testTag = "signup_confirm_password_input"
                    )

                    AnimatedVisibility(visible = errorMessage != null) {
                        errorMessage?.let { msg ->
                            Text(
                                text = msg,
                                color = CoralRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (isLoading) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(28.dp))
                        }
                    } else {
                        GlassButton(
                            text = "Create Account",
                            onClick = {
                                if (fullName.isBlank() || username.isBlank() || email.isBlank() || password.isBlank()) {
                                    errorMessage = "Please fill in all fields"
                                    return@GlassButton
                                }
                                if (password != confirmPassword) {
                                    errorMessage = "Passwords do not match"
                                    return@GlassButton
                                }
                                isLoading = true
                                scope.launch {
                                    val res = repository.signUp(username, email, password, fullName)
                                    isLoading = false
                                    if (res.isSuccess) {
                                        onSignUpSuccess()
                                    } else {
                                        errorMessage = res.exceptionOrNull()?.message ?: "Sign up failed"
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "signup_submit_btn"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Already have an account?",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                TextButton(onClick = onNavigateToLogin) {
                    Text(
                        text = "Sign In",
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun ForgotPasswordScreen(
    repository: StreamixRepository,
    onPasswordResetSuccess: () -> Unit,
    onNavigateToLogin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var email by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isSubmitted by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "RESET PASSWORD",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Text(
                text = "Enter your registered email and a new password",
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = GlassSurfaceDark
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    if (isSubmitted) {
                        Text(
                            text = "Password Reset Successful!",
                            color = NeonCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Your password has been updated securely. You can now log in with your new credentials.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        GlassButton(
                            text = "Back to Sign In",
                            onClick = onNavigateToLogin,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        GlassTextField(
                            value = email,
                            onValueChange = { email = it; message = null },
                            label = "Registered Email",
                            placeholder = "user@example.com",
                            leadingIcon = Icons.Default.Email,
                            testTag = "forgot_email_input"
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        GlassTextField(
                            value = newPassword,
                            onValueChange = { newPassword = it; message = null },
                            label = "New Password",
                            placeholder = "At least 6 characters",
                            leadingIcon = Icons.Default.Lock,
                            isPassword = true,
                            testTag = "forgot_new_password_input"
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        GlassTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it; message = null },
                            label = "Confirm New Password",
                            placeholder = "Re-enter new password",
                            leadingIcon = Icons.Default.Lock,
                            isPassword = true,
                            testTag = "forgot_confirm_password_input"
                        )

                        AnimatedVisibility(visible = message != null) {
                            message?.let { msg ->
                                Text(
                                    text = msg,
                                    color = CoralRed,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        if (isLoading) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(28.dp))
                            }
                        } else {
                            GlassButton(
                                text = "Reset Password",
                                onClick = {
                                    if (email.isBlank() || newPassword.isBlank()) {
                                        message = "Please enter email and new password"
                                        return@GlassButton
                                    }
                                    if (newPassword != confirmPassword) {
                                        message = "Passwords do not match"
                                        return@GlassButton
                                    }
                                    isLoading = true
                                    scope.launch {
                                        val res = repository.resetPassword(email, newPassword)
                                        isLoading = false
                                        if (res.isSuccess) {
                                            isSubmitted = true
                                        } else {
                                            message = res.exceptionOrNull()?.message ?: "Reset failed"
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "forgot_submit_btn"
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(onClick = onNavigateToLogin) {
                Text(
                    text = "Return to Sign In",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }
    }
}
