package com.example.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.Announcement
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.WatchHistory
import com.example.data.repository.StreamixRepository
import com.example.ui.components.CategoryPillRow
import com.example.ui.components.ContinueWatchingRow
import com.example.ui.components.GlassCard
import com.example.ui.components.HeroBanner
import com.example.ui.components.HorizontalContentRow
import com.example.ui.components.StreamixFooter
import com.example.ui.theme.CoralRed
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepIndigoBg
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlassCardBorder
import com.example.ui.theme.GlassSurfaceDark
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyanGradient
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VibrantPurple
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    repository: StreamixRepository,
    onContentClick: (ContentItem) -> Unit,
    onWatchClick: (ContentItem) -> Unit,
    onNavigateToCategory: (String) -> Unit,
    onNavigateToRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allContentDb by repository.getAllPublishedContent().collectAsStateWithLifecycle(emptyList())
    val allContent = if (allContentDb.isEmpty()) com.example.data.repository.SeedData.initialContent else allContentDb
    val categoriesDb by repository.getCategories().collectAsStateWithLifecycle(emptyList())
    val categories = if (categoriesDb.isEmpty()) com.example.data.repository.SeedData.categories else categoriesDb
    val continueWatchingList by repository.getContinueWatchingList().collectAsStateWithLifecycle(emptyList())
    val activeAnnouncements by repository.getActiveAnnouncements().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()

    var dismissedAnnouncementIds by remember { mutableStateOf(setOf<String>()) }
    val visibleAnnouncements = activeAnnouncements.filter { it.id !in dismissedAnnouncementIds }

    var selectedCategorySlug by remember { mutableStateOf("all") }

    val featuredItem = allContent.firstOrNull { it.isFeatured } ?: allContent.firstOrNull()
    val isFeaturedSaved by repository.isContentSaved(featuredItem?.id ?: "").collectAsStateWithLifecycle(false)

    val filteredContent = if (selectedCategorySlug == "all") {
        allContent
    } else {
        allContent.filter { it.categorySlug == selectedCategorySlug || it.type.equals(selectedCategorySlug, ignoreCase = true) }
    }

    val trendingItems = filteredContent.filter { it.isTrending }
    val natokItems = filteredContent.filter { it.type == "NATOK" }
    val filmItems = filteredContent.filter { it.type == "FILM" || it.type == "MOVIE" }
    val seriesItems = filteredContent.filter { it.type == "SERIES" }
    val topRatedItems = filteredContent.filter { it.rating >= 4.7 }.sortedByDescending { it.rating }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        if (allContent.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeonCyan)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .testTag("home_screen_scroll")
            ) {
                // Hero Banner
                if (featuredItem != null && selectedCategorySlug == "all") {
                    HeroBanner(
                        item = featuredItem,
                        onWatchClick = { onWatchClick(featuredItem) },
                        onDetailsClick = { onContentClick(featuredItem) },
                        onMyListToggle = {
                            scope.launch { repository.toggleSaveContent(featuredItem.id) }
                        },
                        isSaved = isFeaturedSaved
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Categories Row
                CategoryPillRow(
                    categories = categories,
                    selectedCategorySlug = selectedCategorySlug,
                    onSelectCategory = { selectedCategorySlug = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Admin Announcements Section (Synced from Firebase/Firestore)
                if (visibleAnnouncements.isNotEmpty() && selectedCategorySlug == "all") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        visibleAnnouncements.forEach { announcement ->
                            HomeAnnouncementCard(
                                announcement = announcement,
                                onDismiss = {
                                    dismissedAnnouncementIds = dismissedAnnouncementIds + announcement.id
                                }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Continue Watching
                if (continueWatchingList.isNotEmpty() && selectedCategorySlug == "all") {
                    ContinueWatchingRow(
                        items = continueWatchingList,
                        onItemClick = { content, _ -> onWatchClick(content) }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Trending Now
                HorizontalContentRow(
                    title = if (selectedCategorySlug == "all") "Trending Now in BD" else "Trending Selection",
                    items = trendingItems.ifEmpty { filteredContent.take(5) },
                    onItemClick = onContentClick,
                    onSeeAllClick = { onNavigateToCategory(selectedCategorySlug) }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Bangla Natok
                if (natokItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Bangla Natok & Eid Specials",
                        items = natokItems,
                        onItemClick = onContentClick,
                        onSeeAllClick = { onNavigateToCategory("natok") }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Films & Blockbusters
                if (filmItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Blockbuster Films & Cinema",
                        items = filmItems,
                        onItemClick = onContentClick,
                        onSeeAllClick = { onNavigateToCategory("films") }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Original Series
                if (seriesItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Original Thriller & Drama Series",
                        items = seriesItems,
                        onItemClick = onContentClick,
                        onSeeAllClick = { onNavigateToCategory("series") }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Top Rated
                if (topRatedItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Critically Acclaimed (4.7+ ★)",
                        items = topRatedItems,
                        onItemClick = onContentClick
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Content Request Callout Card
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    backgroundColor = DeepIndigoBg,
                    borderColor = CrimsonRed.copy(alpha = 0.5f),
                    onClick = onNavigateToRequest
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(RedCrimsonGradient),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PostAdd,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "Missing your favorite Natok or Film?",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Submit a title request to the Streamix team",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Request Content",
                            tint = BrightRedAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Streamix Footer
                StreamixFooter()

                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}

/**
 * Announcement card displayed to users on the Home Screen.
 * Displays photo (if present), title, message, publish date/time, author, and dismiss button.
 */
@Composable
fun HomeAnnouncementCard(
    announcement: Announcement,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH) }
    val formattedDate = remember(announcement.createdAt) {
        dateFormat.format(Date(announcement.createdAt))
    }

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_announcement_card_${announcement.id}"),
        backgroundColor = DeepIndigoBg,
        borderColor = NeonCyan.copy(alpha = 0.5f)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // If image is present, display full width header photo with gradient overlay
            if (announcement.imageUrl.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(DarkNavyBg)
                ) {
                    AsyncImage(
                        model = announcement.imageUrl,
                        contentDescription = announcement.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Subtle bottom gradient to blend with card
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        DeepIndigoBg.copy(alpha = 0.8f)
                                    ),
                                    startY = 60f
                                )
                            )
                    )

                    // Announcement badge over image
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MidnightBlack.copy(alpha = 0.75f))
                            .border(1.dp, NeonCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ANNOUNCEMENT",
                                color = NeonCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // Dismiss 'X' button
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MidnightBlack.copy(alpha = 0.75f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss Announcement",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Card Text Content
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                // If there was no image, show the top header row with badge and dismiss button
                if (announcement.imageUrl.isBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(VibrantPurple.copy(alpha = 0.2f))
                                .border(1.dp, VibrantPurple.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "ANNOUNCEMENT",
                                    color = NeonCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(26.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss Announcement",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Announcement Title
                Text(
                    text = announcement.title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Announcement Message
                Text(
                    text = announcement.message,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Footer: Author and Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "From ${announcement.authorName}",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = formattedDate,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

